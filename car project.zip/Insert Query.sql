USE CarDorm

-- Query to insert data into tables. 

BEGIN TRAN
INSERT INTO [MsStaff] VALUES
	('ST000', 'Jojo Liam', 'Male', 'jojo@gmail.com', '085612712', 'Jalan Raya V no.2' , '6100000'),
	('ST001', 'Adam Noah', 'Male', 'adams@yahoo.com', '0886576723', 'Jalan Mawar VI no.11' , '6100000'),
	('ST002', 'Stan Lucas', 'Male', 'stan@yahoo.com', '088657363', 'Jalan Street IV no.27' , '8500000'),
	('ST003', 'Yesi Isabella', 'Female', 'yesi@gmail.com', '0813192037', 'Jalan Batu II no.37' , '8500000'),
	('ST004', 'Angeline Joy', 'Female', 'angel9@gmail.com', '0858467017', 'Jalan Batu V no.40' , '8500000'),
	('ST005', 'Lay Albed', 'Female', 'lay@yahoo.com', '0856645145', 'Jalan Singa II no.1' , '6100000'),
	('ST006', 'Angeline Joy', 'Female', 'angel@gmail.com', '0858634571', 'Jalan Anggrek III no.7' , '8500000'),
	('ST007', 'Lina Lane', 'Female', 'linaa@gmail.com', '0815888912', 'Jalan Manggis I no. 11' , '6100000'),
	('ST008', 'Joseph Liam', 'Male', 'seph01@gmail.com', '0815071725', 'Jalan Route IX no. 2' , '6100000'),
	('ST009', 'Buzz Vent', 'Male', 'buzz@gmail.com', '0815055170', 'Jalan Kayu IIV no. 33' , '8500000')

COMMIT


BEGIN TRAN
INSERT INTO [MsCustomer] VALUES
	('CU000', 'Aaron Yishmir', 'Male', 'aaron55@yahoo.com', '0812342614', 'Jalan Florence I no. 22'),
	('CU001', 'Christina Georgina ', 'Female', 'christina015@gmail.com', '0812342732', 'Jalan Tambyani IV no. 27'),
	('CU002', 'Bryce Thatcher', 'Male', 'bryce_@gmail.com', '0855542132', 'Jalan Ramesses V no. 47'),
	('CU003', 'Joshua Ott', 'Male', 'Josh_ott@gmail.com', '0816642137', 'Jalan Nosta IX no. 3'),
	('CU004', 'Zachary Clarke', 'Male', 'Clarke@yahoo.com', '0845672155', 'Jalan Kulu X no. 10'),
	('CU005', 'Darius Morgan', 'Male', 'Morgan22@gmail.com', '0878982199', 'Jalan Opaline III no. 13'),
	('CU006', 'Jack Barlow', 'Male', 'jack_jack@gmail.com', '0845352100', 'Jalan Opaline II no. 15'),
	('CU007', 'Vera Walton', 'Female', 'v_w@gmail.com', '081213211', 'Jalan Nosta I no. 11'),
	('CU008', 'Susan Wellington', 'Female', 'sus11@yahoo.com', '0812313241', 'Jalan Mangrove XI no. 9'),
	('CU009', 'Celestine Taylor', 'Female', 'taylor77@yahoo.com', '0812333211', 'Jalan Laide VII no. 33')

COMMIT


BEGIN TRAN
INSERT INTO [MsVendor] VALUES
	('VE000', 'PT General Motors', 'general44@yahoo.com', '086371527', 'Jalan Verse I no. 11'),
	('VE001', 'PT Prospect Motors', 'prospect@yahoo.com', '082532633', 'Jalan Nosta IV no. 22'),
	('VE002', 'PT Pantja Motors', 'pantja@gmail.com', '088253724', 'Jalan Stelis I no. 18'),
	('VE003', 'PT Berlian Motors', 'berlian11@gmail.com', '0829364832', 'Jalan Ramesses VI no. 4'),
	('VE004', 'PT Chrysler Indonesia', 'Chrysler@gmail.com', '083527455', 'Jalan Analects IX no.20'),
	('VE005', 'PT Indomobil', 'indomobil_5@yahoo.com', '084372345', 'Jalan Laide VI no. 7'),
	('VE006', 'PT Motor Manufacturing', 'mm@yahoo.com', '089977548', 'Jalan Kulu X no. 45'),
	('VE007', 'PT Daimler Indonesia', 'daimler@gmail.com', '0866745372', 'Jalan Verse III no. 15'),
	('VE008', 'PT Astro Indonesia', 'astro@yahoo.com', '084638152', 'Jalan Laide V no. 5 '),
	('VE009', 'PT CT Motors', 'ct@gmail.com', '082039030', 'Jalan Verse IX no. 3')

COMMIT


BEGIN TRAN
INSERT INTO [MsCarBrand] VALUES
	('CB000', 'Tayato'),
	('CB001', 'Dihatsu'),
	('CB002', 'Nassin'),
	('CB003', 'Mutsibushu'),
	('CB004', 'Uadi'),
	('CB005', 'Chovrelot'),
	('CB006', 'Vilvi'),
	('CB007', 'Masdah'),
	('CB008', 'Kai'),
	('CB009', 'Luxes')

COMMIT


BEGIN TRAN
INSERT INTO [MsCar] VALUES
	('CA000', 'CB000', 'Innove', '565000000', '11'),
	('CA001', 'CB001', 'Copan', '200000000', '10'),
	('CA002', 'CB002', 'Sereno', '456000000', '7'),
	('CA003', 'CB003', 'Xpandor', '250000000', '12'),
	('CA004', 'CB004', 'A3', '710000000', '6'),
	('CA005', 'CB005', 'Captivo', '510000000', '7'),
	('CA006', 'CB006', 'SUV', '190000000', '8'),
	('CA007', 'CB007', 'CZI', '150000000', '6'),
	('CA008', 'CB008', 'Conet', '230000000', '9'),
	('CA009', 'CB009', 'Coupa', '411000000', '5')

COMMIT


BEGIN TRAN
INSERT INTO [TransactionCustomer] VALUES
	('TR000', 'ST006', 'CU000', '2019-04-11 13:23'),
	('TR001', 'ST006', 'CU000', '2019-04-15 17:23'),
	('TR002', 'ST006', 'CU000', '2019-11-16 16:17'),
	('TR003', 'ST003', 'CU009', '2019-11-30 10:20'),
	('TR004', 'ST003', 'CU009', '2019-11-30 15:00'),
	('TR005', 'ST005', 'CU003', '2019-12-09 18:27'),
	('TR006', 'ST007', 'CU004', '2019-12-14 14:09'),
	('TR007', 'ST009', 'CU005', '2019-12-23 16:11'),
	('TR008', 'ST002', 'CU001', '2019-12-31 10:28'),
	('TR009', 'ST002', 'CU001', '2019-12-31 17:33'),
	('TR010', 'ST008', 'CU008', '2020-01-17 09:12'),
	('TR011', 'ST008', 'CU008', '2020-01-17 10:05'),
	('TR012', 'ST003', 'CU001', '2020-01-30 13:01'),
	('TR013', 'ST001', 'CU002', '2020-02-04 11:19'),
	('TR014', 'ST005', 'CU003', '2020-02-19 15:30')


	COMMIT
	select * from TransactionCustomer

BEGIN TRAN
INSERT INTO [TransactionCustomerDetail] VALUES
	('TR000', 'CA002', '1'),
	('TR000', 'CA003', '1'),
	('TR000', 'CA004', '1'),
	('TR001', 'CA005', '2'),
	('TR001', 'CA009', '1'),
	('TR002', 'CA009', '1'),
	('TR003', 'CA007', '1'),
	('TR003', 'CA001', '1'),
	('TR004', 'CA001', '1'),
	('TR005', 'CA002', '1'),
	('TR005', 'CA006', '1'),
	('TR005', 'CA009', '1'),
	('TR006', 'CA001', '1'),
	('TR007', 'CA003', '1'),
	('TR007', 'CA002', '2'),
	('TR008', 'CA004', '1'),
	('TR009', 'CA008', '1'),
	('TR010', 'CA006', '1'),
	('TR010', 'CA004', '1'),
	('TR011', 'CA009', '2'),
	('TR012', 'CA003', '1'),
	('TR012', 'CA006', '1'),
	('TR013', 'CA001', '1'),
	('TR013', 'CA004', '1'),
	('TR014', 'CA000', '2')

	COMMIT
	select * from TransactionCustomerDetail


BEGIN TRAN
INSERT INTO [PurchaseVendor] VALUES
	('PU000', 'ST006', 'VE000', '2018-11-11 13:23'),
	('PU001', 'ST006', 'VE000', '2018-11-15 17:23'),
	('PU002', 'ST006', 'VE000', '2018-11-16 16:17'),
	('PU003', 'ST003', 'VE009', '2018-11-30 10:20'),
	('PU004', 'ST003', 'VE009', '2018-11-30 15:00'),
	('PU005', 'ST005', 'VE003', '2018-12-09 18:27'),
	('PU006', 'ST007', 'VE004', '2018-12-14 14:09'),
	('PU007', 'ST009', 'VE005', '2018-12-23 16:11'),
	('PU008', 'ST002', 'VE001', '2018-12-31 10:28'),
	('PU009', 'ST002', 'VE001', '2018-12-31 17:33'),
	('PU010', 'ST008', 'VE008', '2019-01-17 09:12'),
	('PU011', 'ST008', 'VE008', '2019-01-17 10:05'),
	('PU012', 'ST003', 'VE001', '2019-01-30 13:01'),
	('PU013', 'ST001', 'VE002', '2019-02-04 11:19'),
	('PU014', 'ST005', 'VE003', '2019-02-19 15:30')

	COMMIT
	select * from PurchaseVendor

BEGIN TRAN
INSERT INTO [PurchaseVendorDetail] VALUES
	('PU000', 'CA002', '2'),
	('PU000', 'CA003', '3'),
	('PU000', 'CA004', '3'),
	('PU001', 'CA005', '2'),
	('PU001', 'CA009', '3'),
	('PU002', 'CA009', '3'),
	('PU003', 'CA007', '3'),
	('PU003', 'CA001', '2'),
	('PU004', 'CA001', '3'),
	('PU005', 'CA002', '2'),
	('PU005', 'CA006', '4'),
	('PU005', 'CA009', '3'),
	('PU006', 'CA001', '3'),
	('PU007', 'CA003', '3'),
	('PU007', 'CA002', '2'),
	('PU008', 'CA004', '2'),
	('PU009', 'CA008', '2'),
	('PU010', 'CA006', '3'),
	('PU010', 'CA004', '4'),
	('PU011', 'CA009', '2'),
	('PU012', 'CA003', '5'),
	('PU012', 'CA006', '2'),
	('PU013', 'CA001', '5'),
	('PU013', 'CA004', '6'),
	('PU014', 'CA000', '5')

	COMMIT
	SELECT * FROM PurchaseVendorDetail