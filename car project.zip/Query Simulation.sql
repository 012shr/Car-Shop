-- Query to simulate the transactions processes. 

-- Purchasing cars from a vendor --

SELECT * 
    FROM MsVendor
    WHERE VendorName = 'PT Gaya Motor'

BEGIN TRAN
INSERT INTO [MsVendor] VALUES
    ('VE010', 'PT Gaya Motor,', 'Gaya_1@yahoo.com', '0863522520', 'Jalan Verse X no. 1')

COMMIT


SELECT CarID, CarName, CarStock 
    FROM MsCar
    WHERE CarName = 'A3'

BEGIN TRAN
INSERT INTO [PurchaseVendor] VALUES
    ('PU015', 'ST005', 'VE010', '2019-03-11 12:27')

COMMIT


BEGIN TRAN
INSERT INTO [PurchaseVendorDetail] VALUES
    ('PU015', 'CA004', '4')

COMMIT


BEGIN TRAN
UPDATE [MsCar] 
    SET CarStock = Carstock + '4'
    WHERE CarID = 'CA004' 

COMMIT



-- Selling cars to a customer --

SELECT * 
    FROM MsCustomer
    WHERE CustomerName = 'Neil Hume'

BEGIN TRAN
INSERT INTO [MsCustomer] VALUES
    ('CU010', 'Neil Hume', 'Male', 'neil_hume@gmail.com', '0863425528', 'Jalan Sky II no. 2')

COMMIT

SELECT *
    FROM MsCar
    WHERE CarName IN ('A3','Captivo','SUV')

BEGIN TRAN
INSERT INTO [TransactionCustomer] VALUES
    ('TR015', 'ST005', 'CU010', '2020-03-11 11:44')

COMMIT

BEGIN TRAN
INSERT INTO [TransactionCustomerDetail] VALUES
    ('TR015', 'CA004', '1'),
    ('TR015', 'CA005', '1'),
    ('TR015', 'CA006', '1')

COMMIT

BEGIN TRAN
UPDATE [MsCar] 
    SET CarStock = Carstock - '1'
    WHERE CarID = 'CA004' 

COMMIT

BEGIN TRAN
UPDATE [MsCar] 
    SET CarStock = Carstock - '1'
    WHERE CarID = 'CA005' 

COMMIT

BEGIN TRAN
UPDATE [MsCar] 
    SET CarStock = Carstock - '1'
    WHERE CarID = 'CA006' 

COMMIT