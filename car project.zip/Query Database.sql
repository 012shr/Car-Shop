CREATE DATABASE cArDorm
GO
USE cArDorm

--CREATE TABLE
CREATE TABLE [MsStaff] (
	StaffID CHAR(5) PRIMARY KEY CHECK (StaffID LIKE 'ST[0-9][0-9][0-9]') NOT NULL,
	StaffName VARCHAR(50) CHECK (LEN(StaffName)>= 2) NOT NULL,
	StaffGender VARCHAR(10) CHECK (StaffGender IN ('Male', 'Female')) NOT NULL,
	StaffEmail VARCHAR(50) CHECK (StaffEmail LIKE '%@gmail.com' OR StaffEmail LIKE '%@yahoo.com')NOT NULL,
	StaffPhoneNumber VARCHAR(10) NOT NULL,
	StaffAddress VARCHAR(50) NOT NULL,
	StaffSalary INT CHECK (StaffSalary BETWEEN 5000000 AND 10000000) NOT NULL
);


CREATE TABLE [MsCustomer] (
	CustomerID CHAR(5) PRIMARY KEY CHECK (CustomerID LIKE 'CU[0-9][0-9][0-9]') NOT NULL,
	CustomerName VARCHAR(50) CHECK (LEN(CustomerName)>= 2) NOT NULL,
	CustomerGender VARCHAR(10) CHECK (CustomerGender IN ('Male', 'Female')) NOT NULL,
	CustomerEmail VARCHAR(50) CHECK (CustomerEmail LIKE '%@gmail.com' OR CustomerEmail LIKE '%@yahoo.com') NOT NULL,
	CustomerPhoneNumber VARCHAR(10) NOT NULL,
	CustomerAddress VARCHAR(50) NOT NULL,
);


CREATE TABLE [MsVendor] (
	VendorID CHAR(5) PRIMARY KEY CHECK (VendorID LIKE 'VE[0-9][0-9][0-9]') NOT NULL,
	VendorName VARCHAR(50) CHECK (LEN(VendorName)>= 2) NOT NULL,
	VendorEmail VARCHAR(50) CHECK (VendorEmail LIKE '%@gmail.com' OR VendorEmail LIKE '%@yahoo.com') NOT NULL,
	VendorPhoneNumber VARCHAR(10) NOT NULL,
	VendorAddress VARCHAR(50) NOT NULL,
);


CREATE TABLE [MsCarBrand] (
	CarBrandID CHAR(5) PRIMARY KEY CHECK (CarBrandID Like 'CB[0-9][0-9][0-9]') NOT NULL,
	CarBrandName VARCHAR(50) NOT NULL
);



CREATE TABLE [MsCar] (
	CarID CHAR(5) PRIMARY KEY CHECK (CarID LIKE 'CA[0-9][0-9][0-9]') NOT NULL,
	CarBrandID CHAR(5) FOREIGN KEY REFERENCES MsCarBrand(CarBrandID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	CarName VARCHAR(50) NOT NULL,
	CarPrice FLOAT NOT NULL,
	CarStock INT NOT NULL
);



CREATE TABLE [PurchaseVendor] (
	PurchaseVendorID CHAR(5) PRIMARY KEY CHECK (PurchaseVendorID LIKE 'PU[0-9][0-9][0-9]') NOT NULL,
	StaffID CHAR(5) FOREIGN KEY REFERENCES MsStaff(StaffID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	VendorID CHAR(5) FOREIGN KEY REFERENCES MsVendor(VendorID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	PurchaseVendorDate SMALLDATETIME CHECK (PurchaseVendorDate <= CURRENT_TIMESTAMP) NOT NULL
);



CREATE TABLE [PurchaseVendorDetail] (
	PurchaseVendorID CHAR(5) FOREIGN KEY REFERENCES PurchaseVendor(PurchaseVendorID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	CarID CHAR(5) FOREIGN KEY REFERENCES MsCar(CarID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	Quantity INT NOT NULL,
	PRIMARY KEY(PurchaseVendorID, CarID)
);


CREATE TABLE [TransactionCustomer](
	TransactionCustomerID CHAR(5) PRIMARY KEY CHECK (TransactionCustomerID LIKE 'TR[0-9][0-9][0-9]'),
	StaffID CHAR(5) FOREIGN KEY REFERENCES MsStaff(StaffID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	CustomerID CHAR(5) FOREIGN KEY REFERENCES MsCustomer(CustomerID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	TransactionCustomerDate SMALLDATETIME CHECK (TransactionCustomerDate <= CURRENT_TIMESTAMP) NOT NULL
);



CREATE TABLE [TransactionCustomerDetail] (
	TransactionCustomerID CHAR(5) FOREIGN KEY REFERENCES TransactionCustomer(TransactionCustomerID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	CarID CHAR(5) FOREIGN KEY REFERENCES MsCar(CarID) ON UPDATE CASCADE ON DELETE CASCADE NOT NULL,
	Quantity INT NOT NULL,
	PRIMARY KEY(TransactionCustomerID, CarID)
);
