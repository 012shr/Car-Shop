USE CarDorm

-- 1
SELECT
    CONCAT ('Mrs. ',CustomerName) AS CustomerName, 
    UPPER(CustomerGender) AS CustomerGender, 
    COUNT(MsCustomer.CustomerID) AS [TotalTransaction]
FROM
    MsCustomer JOIN TransactionCustomer 
    ON MsCustomer.CustomerID = TransactionCustomer.CustomerID
WHERE
     CustomerName like '% %' 
     AND CustomerGender like 'Female'
GROUP BY
    CustomerName, CustomerGender

-- 2
SELECT
    MsCar.CarID, CarName, CarBrandName, CarPrice, 
    CONCAT(SUM (Quantity), ' Car(s)') AS [Total of Car That Has Been Sold]
FROM
    MsCar 
    JOIN TransactionCustomerDetail ON MsCar.CarID = TransactionCustomerDetail.CarID 
    JOIN MsCarBrand ON MsCar.CarBrandID = MsCarBrand.CarBrandID
WHERE
    CarPrice > 300000000 AND RIGHT(MsCar.CarID,3) % 2 = 1
GROUP BY 
    MsCar.CarID, CarName, CarBrandName, CarPrice
HAVING
    SUM (Quantity) > 1

-- 3
SELECT
    REPLACE (MsStaff.StaffID,'ST', 'Staff') AS [StaffId],
    StaffName,
    COUNT(TransactionCustomer.TransactionCustomerID) AS [Total Transaction Handled],
    MAX(TransactionCustomerDetail.Quantity) AS [Maximum Quantity in One Transaction]

FROM
    MsStaff
    JOIN TransactionCustomer
    ON MsStaff.StaffID = TransactionCustomer.StaffID
    JOIN TransactionCustomerDetail
    ON TransactionCustomer.TransactionCustomerID = TransactionCustomerDetail.TransactionCustomerID
    
WHERE
    FORMAT(TransactionCustomerDate, 'MMMM', 'en-US') = 'April'
     
GROUP BY 
    MsStaff.StaffID, StaffName
HAVING 
    COUNT(TransactionCustomer.TransactionCustomerID) > 1
ORDER BY 
    MAX(TransactionCustomerDetail.Quantity) DESC
	

-- 4
SELECT
    CustomerName, LEFT(CustomerGender,1) AS CustomerGender,
    COUNT(MsCustomer.CustomerID) AS [Total Purchase],
    SUM (Quantity) AS [Total of Car That Has Been Purchased]

FROM
    MsCustomer 
    JOIN TransactionCustomer 
    ON MsCustomer.CustomerID = TransactionCustomer.CustomerID
    JOIN TransactionCustomerDetail 
    ON TransactionCustomer.TransactionCustomerID = TransactionCustomerDetail.TransactionCustomerID
WHERE
    CustomerEmail like '%@gmail.com'
GROUP BY
    CustomerName, CustomerGender
HAVING 
    SUM (Quantity) > 2

-- 5
SELECT 
    REPLACE (VendorName, 'PT', 'Perseroan Trebatas') AS VendorName, 
    VendorPhoneNumber, RIGHT(PurchaseVendor.PurchaseVendorID,3) AS [Purchase ID Number], 
    SUM(Quantity)AS Quantity
FROM
    MsVendor
    JOIN PurchaseVendor
    ON MsVendor.VendorID = PurchaseVendor.VendorID
    JOIN PurchaseVendorDetail
    ON PurchaseVendor.PurchaseVendorID = PurchaseVendorDetail.PurchaseVendorID
WHERE

        VendorName like '%a%'
GROUP BY 
    VendorName, VendorPhoneNumber, PurchaseVendor.PurchaseVendorID
HAVING
SUM(Quantity) > (
            SELECT AVG(b)
            FROM  
                (
                SELECT SUM(Quantity) AS b
                FROM PurchaseVendorDetail
                JOIN MsCar
                ON MsCar.CarID = PurchaseVendorDetail.CarID
                GROUP BY CarName
                ) a
            
            )

-- 6
SELECT
    UPPER (CONCAT (MsCarBrand.CarBrandName, ' ', MsCar.CarName)) AS [Name], 
    'Rp. ' + CONVERT (VARCHAR(50), CAST (CarPrice AS MONEY),1) AS [Price],
    CONCAT (CarStock, ' Stock(s)') AS [Stock]
FROM 
    MsCarBrand
    JOIN
    MsCar
    ON MsCar.CarBrandID = MsCarBrand.CarBrandID
WHERE
        CarName like '%e%'
        AND 
        CarPrice >
        (SELECT AVG(CarPrice)
            FROM MsCar )
GROUP BY
    CarBrandName, CarName, CarPrice, CarStock ;

-- 7
SELECT
    RIGHT (MsCar.CarID, 3) AS [Car ID Number], 
    CarName, 
    UPPER (CarBrandName) AS [Brand], 
    'Rp. ' + CONVERT (VARCHAR(50), CAST (CarPrice AS MONEY),1) AS [Price], 
    SUM (Quantity) AS [Total of Car That Has Been Sold]
FROM
    MsCar 
    JOIN TransactionCustomerDetail 
    ON MsCar.CarID = TransactionCustomerDetail.CarID 
    JOIN MsCarBrand
    ON MsCar.CarBrandID = MsCarBrand.CarBrandID

WHERE 
    CarName like '%o%' AND 
    CarPrice > 200000000
    
GROUP BY
    MsCar.CarID, CarName, CarBrandName, CarPrice
HAVING
SUM(Quantity) > (
	SELECT AVG(b)
	FROM (
	SELECT SUM(Quantity) AS b
	FROM TransactionCustomerDetail
	JOIN MsCar
	ON MsCar.CarID = TransactionCustomerDetail.CarID
	GROUP BY CarName
	) a
		)

-- 8
SELECT 
    SUBSTRING (StaffName,1 ,CHARINDEX(' ', StaffName) - 1)  AS [Staff First Name],
    SUBSTRING (StaffName,CHARINDEX(' ', StaffName) + 1, LEN(StaffName) - CHARINDEX (' ', StaffName)) AS [Staff Last Name],
    SUM (Quantity) AS [Total of Car That Has Been Sold]
FROM
    MsStaff
    JOIN TransactionCustomer
    ON MsStaff.StaffID = TransactionCustomer.StaffID
    JOIN TransactionCustomerDetail
    ON TransactionCustomer.TransactionCustomerID = TransactionCustomerDetail.TransactionCustomerID
    
WHERE
     StaffName like '% %'
     
GROUP BY
    StaffName
HAVING
SUM(Quantity) > 
    (
            SELECT AVG(b)
            FROM  
                (
                SELECT SUM(Quantity) AS b
                FROM TransactionCustomerDetail
                JOIN MsCar
                ON MsCar.CarID = TransactionCustomerDetail.CarID
                GROUP BY CarName
                ) a
            
            )

--9 
CREATE VIEW Vendor_Transaction_Handled_and_Minimum_View AS

SELECT
    REPLACE (MsVendor.VendorID, 'VE','Vendor') AS [Vendor ID], 
    VendorName, 
    COUNT (PurchaseVendor.PurchaseVendorID) AS [Total Transaction Handled], 
    MIN(PurchaseVendorDetail.Quantity) AS [Minimum Purchases in One Transaction]
FROM
    MsVendor 
    JOIN PurchaseVendor 
    ON MsVendor.VendorID = PurchaseVendor.VendorID
    JOIN PurchaseVendorDetail
    ON PurchaseVendor.PurchaseVendorID = PurchaseVendorDetail.PurchaseVendorID

WHERE
    VendorName like '%a%' AND FORMAT(PurchaseVendorDate, 'MMMM', 'en-US') = 'May'

GROUP BY
    MsVendor.VendorID, VendorName

-- 10
CREATE VIEW Staff_Total_Purchase_and_Max_Car_Purchase_View AS

SELECT
    MsStaff.StaffID, 
    StaffName, 
    UPPER(StaffEmail) AS [StaffEmail],
    COUNT (PurchaseVendor.StaffID) AS [Total Purchase],
    MAX (PurchaseVendorDetail.Quantity) AS [Maximum of Car That Has Been Purchased in One Purchase]
FROM
    MsStaff
    JOIN PurchaseVendor
    ON PurchaseVendor.StaffID = MsStaff.StaffID
    JOIN PurchaseVendorDetail
    ON PurchaseVendorDetail.PurchaseVendorID = PurchaseVendor.PurchaseVendorID
WHERE 
    StaffEmail like '%@yahoo.com' AND StaffGender like 'Female'
GROUP BY
    MsStaff.StaffID, StaffName, StaffEmail

